# Financial Mathematics Calculator

A comprehensive, interactive financial mathematics calculator built with **Java Spring Boot**. Covers the core topics of the theory of interest — compound interest, present value, force of interest, and annuities — with live charts, dynamic sliders, and precise number inputs. All calculations run on the Java backend and are served to the browser via a REST API.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Backend | Java 17, Spring Boot 3.2 |
| REST API | Spring MVC (`@RestController`) |
| Frontend template | Thymeleaf |
| Charts | Chart.js 4.4.1 (CDN) |
| Typography | DM Serif Display, DM Sans, DM Mono (Google Fonts) |
| Build tool | Maven |

---

## Project Structure

```
financial-mathematics-calculator/
├── pom.xml
└── src/main/
    ├── java/com/finmath/calculator/
    │   ├── FinancialMathApplication.java        ← Spring Boot entry point
    │   ├── controller/
    │   │   ├── PageController.java              ← Serves the HTML page at /
    │   │   └── CalculatorController.java        ← REST API at /api/*
    │   ├── service/
    │   │   └── FinancialMathService.java        ← All calculation logic
    │   └── model/
    │       └── CalculationModels.java           ← Request/response POJOs
    └── resources/
        ├── application.properties
        └── templates/
            └── index.html                       ← Thymeleaf template (HTML + CSS + JS)
```

---

## API Endpoints

All endpoints accept `POST` with a JSON body and return a JSON response.

| Endpoint | Description |
|---|---|
| `POST /api/compound` | Compound interest calculation |
| `POST /api/pv` | Present value and discount rate |
| `POST /api/foi` | Force of interest and rate equivalence table |
| `POST /api/annuity` | All annuity types including increasing/decreasing |

### Example — Compound Interest

**Request**
```json
POST /api/compound
{
  "principal": 1000,
  "rate": 7,
  "years": 20,
  "n": 12
}
```

**Response**
```json
{
  "finalBalance": 4038.74,
  "interestEarned": 3038.74,
  "growthMultiple": 4.04,
  "returnPct": 303.87,
  "doublingYears": 10.24,
  "ear": 7.2290,
  "totalPeriods": 240,
  "labels": ["Now", "Y1", "Y2", ...],
  "compoundSeries": [1000, 1074.42, ...],
  "simpleSeries": [1000, 1070, ...]
}
```

---

## Features

### Four Calculation Modules

**Compound Interest**
- Final balance, interest earned, Rule of 72 doubling time
- Compound vs. simple growth comparison chart
- Annual, semi-annual, quarterly, monthly, and daily compounding
- Effective Annual Rate (EAR) and total period count

**Discount Rates & Present Value**
- Present value from future cash flow at a given discount rate
- Discount factor v^t and equivalent discount rate d
- PV decay chart over time vs. fixed FV
- Reference table of v^t and d at standard horizons

**Force of Interest**
- δ = ln(1+i) derived from the annual effective rate
- Continuous vs. annual vs. monthly compounding chart
- Full rate equivalence table: i, i^(2), i^(4), i^(12), δ, d, d^(2), δ_d

**Annuities**
- Six annuity types: immediate, due, deferred, perpetuity-immediate, perpetuity-due, continuous
- Increasing and decreasing annuities with:
  - Arithmetic variation (fixed change Q per period)
  - Geometric variation (fixed growth rate g per period)
  - Configurable start and stop periods for the variation
- PV, accumulated value (AV), and unit factors a and s
- Cumulative PV/AV chart with payment-per-period bar overlay for varying annuities

---

## Interface

- **Sliders + number inputs** — every parameter has both a drag slider and a precise number field, kept in sync
- **Live metric cards** — key results update instantly at the top of each tab
- **Interactive charts** — Chart.js with theme-aware colors and tooltips
- **Light / Dark mode** — compact dropdown in the header; light mode is the default
- **Responsive layout** — collapses to single-column on narrow viewports

---

## Getting Started

### Prerequisites

- Java 17+
- Maven 3.8+

### Run

```bash
git clone https://github.com/your-username/financial-mathematics-calculator.git
cd financial-mathematics-calculator
mvn spring-boot:run
```

Then open [http://localhost:8080](http://localhost:8080) in your browser.

### Build a JAR

```bash
mvn clean package
java -jar target/financial-mathematics-calculator-1.0.0.jar
```

---

## Formulas Reference

| Concept | Formula |
|---|---|
| Compound interest | A = P(1 + r/n)^(nt) |
| Present value | PV = FV · (1 + i)^(−t) |
| Discount factor | v = 1/(1 + i) |
| Discount rate | d = i/(1 + i) = 1 − v |
| Force of interest | δ = ln(1 + i) |
| Continuous accumulation | A(t) = Pe^(δt) |
| Annuity-immediate PV | a_n&#124;i = (1 − v^n) / i |
| Annuity-due PV | ä_n&#124;i = (1 − v^n) / d |
| Continuous annuity PV | ā_n&#124;δ = (1 − e^(−δn)) / δ |
| Perpetuity-immediate | PV = PMT / i |
| Perpetuity-due | PV = PMT / d |

---

## License

MIT — free to use, modify, and distribute.
