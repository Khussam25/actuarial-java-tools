package com.finmath.calculator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinancialMathApplication {
    public static void main(String[] args) {
        SpringApplication.run(FinancialMathApplication.class, args);
    }
}
