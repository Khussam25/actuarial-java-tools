package com.finmath.calculator.controller;

import com.finmath.calculator.model.CalculationModels.*;
import com.finmath.calculator.service.FinancialMathService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class CalculatorController {

    private final FinancialMathService service;

    public CalculatorController(FinancialMathService service) {
        this.service = service;
    }

    @PostMapping("/compound")
    public CompoundResponse compound(@RequestBody CompoundRequest req) {
        return service.calculateCompound(req);
    }

    @PostMapping("/pv")
    public PresentValueResponse presentValue(@RequestBody PresentValueRequest req) {
        return service.calculatePV(req);
    }

    @PostMapping("/foi")
    public ForceOfInterestResponse forceOfInterest(@RequestBody ForceOfInterestRequest req) {
        return service.calculateFOI(req);
    }

    @PostMapping("/annuity")
    public AnnuityResponse annuity(@RequestBody AnnuityRequest req) {
        return service.calculateAnnuity(req);
    }
}
