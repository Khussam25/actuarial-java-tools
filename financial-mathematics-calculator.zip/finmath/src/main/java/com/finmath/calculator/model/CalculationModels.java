package com.finmath.calculator.model;

public class CalculationModels {

    // ── Compound Interest ────────────────────────────────────────────────────

    public static class CompoundRequest {
        public double principal;
        public double rate;       // annual rate as percentage (e.g. 7 = 7%)
        public int    years;
        public int    n;          // compounding frequency per year
    }

    public static class CompoundResponse {
        public double finalBalance;
        public double interestEarned;
        public double growthMultiple;
        public double returnPct;
        public double doublingYears;
        public double ear;        // effective annual rate
        public int    totalPeriods;
        public double[] compoundSeries;
        public double[] simpleSeries;
        public String[] labels;
    }

    // ── Present Value & Discount ─────────────────────────────────────────────

    public static class PresentValueRequest {
        public double futureValue;
        public double rate;       // annual rate as percentage
        public int    years;
    }

    public static class PresentValueResponse {
        public double presentValue;
        public double discountFactor;  // v^t
        public double discountRateD;   // d = i/(1+i)
        public double[] pvSeries;
        public double[] fvSeries;
        public String[] labels;
        public TableRow[] tableRows;

        public static class TableRow {
            public int    year;
            public double pv;
            public double vt;
            public double d;
            public TableRow(int year, double pv, double vt, double d) {
                this.year = year; this.pv = pv; this.vt = vt; this.d = d;
            }
        }
    }

    // ── Force of Interest ────────────────────────────────────────────────────

    public static class ForceOfInterestRequest {
        public double principal;
        public double rate;   // annual effective rate as percentage
        public int    years;
    }

    public static class ForceOfInterestResponse {
        public double delta;            // force of interest
        public double continuousBalance;
        public double nominalContinuous;
        public double forceOfDiscount;
        public double[] continuousSeries;
        public double[] annualSeries;
        public double[] monthlySeries;
        public String[] labels;
        public RateRow[] rateTable;

        public static class RateRow {
            public String name;
            public String symbol;
            public String formula;
            public String value;
            public RateRow(String name, String symbol, String formula, String value) {
                this.name = name; this.symbol = symbol;
                this.formula = formula; this.value = value;
            }
        }
    }

    // ── Annuities ────────────────────────────────────────────────────────────

    public static class AnnuityRequest {
        public double  pmt;
        public double  rate;     // as percentage
        public int     n;
        public String  type;     // immediate | due | deferred | perpetuity | perp-due | continuous | increasing | decreasing
        public String  varyMode; // arithmetic | geometric
        public double  q;        // arithmetic change amount
        public int     ks;       // change start period
        public int     ke;       // change end period
        public double  g;        // geometric growth rate as percentage
        public int     gs;       // growth start period
        public int     ge;       // growth end period
    }

    public static class AnnuityResponse {
        public double   pv;
        public double   av;
        public double   unitA;
        public double   unitS;
        public String   pvFormula;
        public String   avFormula;
        public String   info;
        public double[] cumPV;
        public double[] cumAV;
        public double[] pmtBars;   // only for increasing/decreasing
        public String[] labels;
    }
}
