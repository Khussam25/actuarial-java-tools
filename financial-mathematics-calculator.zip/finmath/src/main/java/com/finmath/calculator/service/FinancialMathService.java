package com.finmath.calculator.service;

import com.finmath.calculator.model.CalculationModels.*;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class FinancialMathService {

    // ── Compound Interest ────────────────────────────────────────────────────

    public CompoundResponse calculateCompound(CompoundRequest req) {
        double P = req.principal;
        double r = req.rate / 100.0;
        int    t = req.years;
        int    n = req.n;

        double finalBalance   = P * Math.pow(1 + r / n, (double) n * t);
        double interestEarned = finalBalance - P;
        double ear            = Math.pow(1 + r / n, n) - 1;
        double doublingYears  = Math.log(2) / Math.log(1 + ear);

        // Build series (step every year)
        int    step   = t <= 20 ? 1 : Math.max(1, t / 20);
        List<String> labels   = new ArrayList<>();
        List<Double> compound = new ArrayList<>();
        List<Double> simple   = new ArrayList<>();

        for (int y = 0; y <= t; y += step) {
            labels.add(y == 0 ? "Now" : "Y" + y);
            compound.add(P * Math.pow(1 + r / n, (double) n * y));
            simple.add(P * (1 + r * y));
        }

        CompoundResponse res = new CompoundResponse();
        res.finalBalance    = finalBalance;
        res.interestEarned  = interestEarned;
        res.growthMultiple  = finalBalance / P;
        res.returnPct       = (interestEarned / P) * 100;
        res.doublingYears   = doublingYears;
        res.ear             = ear * 100;
        res.totalPeriods    = n * t;
        res.labels          = labels.toArray(new String[0]);
        res.compoundSeries  = compound.stream().mapToDouble(Double::doubleValue).toArray();
        res.simpleSeries    = simple.stream().mapToDouble(Double::doubleValue).toArray();
        return res;
    }

    // ── Present Value & Discount ─────────────────────────────────────────────

    public PresentValueResponse calculatePV(PresentValueRequest req) {
        double FV = req.futureValue;
        double i  = req.rate / 100.0;
        int    t  = req.years;

        double v  = 1.0 / (1 + i);
        double vt = Math.pow(v, t);
        double PV = FV * vt;
        double d  = i / (1 + i);

        int maxT = Math.max(t + 5, 15);
        List<String> labels  = new ArrayList<>();
        List<Double> pvLine  = new ArrayList<>();
        List<Double> fvLine  = new ArrayList<>();

        for (int y = 0; y <= maxT; y++) {
            labels.add(y == 0 ? "Now" : "Y" + y);
            pvLine.add(FV * Math.pow(v, y));
            fvLine.add(FV);
        }

        int[] tableYears = {1, 2, 3, 5, 7, 10, 15, 20, 25, 30};
        List<PresentValueResponse.TableRow> rows = new ArrayList<>();
        for (int y : tableYears) {
            if (y <= t + 5) {
                double vty = Math.pow(v, y);
                rows.add(new PresentValueResponse.TableRow(y, FV * vty, vty, d));
            }
        }

        PresentValueResponse res = new PresentValueResponse();
        res.presentValue   = PV;
        res.discountFactor = vt;
        res.discountRateD  = d * 100;
        res.labels         = labels.toArray(new String[0]);
        res.pvSeries       = pvLine.stream().mapToDouble(Double::doubleValue).toArray();
        res.fvSeries       = fvLine.stream().mapToDouble(Double::doubleValue).toArray();
        res.tableRows      = rows.toArray(new PresentValueResponse.TableRow[0]);
        return res;
    }

    // ── Force of Interest ────────────────────────────────────────────────────

    public ForceOfInterestResponse calculateFOI(ForceOfInterestRequest req) {
        double P     = req.principal;
        double i     = req.rate / 100.0;
        int    t     = req.years;
        double delta = Math.log(1 + i);
        double d     = i / (1 + i);

        List<String> labels    = new ArrayList<>();
        List<Double> contSeries  = new ArrayList<>();
        List<Double> annualSeries = new ArrayList<>();
        List<Double> monthlySeries = new ArrayList<>();

        for (int y = 0; y <= t; y++) {
            labels.add(y == 0 ? "Now" : "Y" + y);
            contSeries.add(P * Math.exp(delta * y));
            annualSeries.add(P * Math.pow(1 + i, y));
            monthlySeries.add(P * Math.pow(1 + i / 12.0, 12.0 * y));
        }

        ForceOfInterestResponse.RateRow[] rateTable = {
            new ForceOfInterestResponse.RateRow("Annual effective",    "i",     "—",                          fmt(i * 100, 4) + "%"),
            new ForceOfInterestResponse.RateRow("Semi-annual nominal", "i^(2)", "2[(1+i)^(1/2)−1]",          fmt(2 * (Math.pow(1+i, 0.5) - 1) * 100, 4) + "%"),
            new ForceOfInterestResponse.RateRow("Quarterly nominal",   "i^(4)", "4[(1+i)^(1/4)−1]",          fmt(4 * (Math.pow(1+i, 0.25) - 1) * 100, 4) + "%"),
            new ForceOfInterestResponse.RateRow("Monthly nominal",     "i^(12)","12[(1+i)^(1/12)−1]",        fmt(12 * (Math.pow(1+i, 1.0/12) - 1) * 100, 4) + "%"),
            new ForceOfInterestResponse.RateRow("Force of interest",   "δ",     "ln(1+i)",                    fmt(delta * 100, 4) + "%"),
            new ForceOfInterestResponse.RateRow("Annual discount",     "d",     "i/(1+i)",                    fmt(d * 100, 4) + "%"),
            new ForceOfInterestResponse.RateRow("Semi-annual discount","d^(2)", "2[1−(1+i)^(−1/2)]",         fmt(2 * (1 - Math.pow(1+i, -0.5)) * 100, 4) + "%"),
            new ForceOfInterestResponse.RateRow("Force of discount",   "δ_d",   "−ln(1−d)",                   fmt(-Math.log(1 - d) * 100, 4) + "%")
        };

        ForceOfInterestResponse res = new ForceOfInterestResponse();
        res.delta              = delta;
        res.continuousBalance  = P * Math.exp(delta * t);
        res.nominalContinuous  = delta;
        res.forceOfDiscount    = -Math.log(1 - d);
        res.labels             = labels.toArray(new String[0]);
        res.continuousSeries   = contSeries.stream().mapToDouble(Double::doubleValue).toArray();
        res.annualSeries       = annualSeries.stream().mapToDouble(Double::doubleValue).toArray();
        res.monthlySeries      = monthlySeries.stream().mapToDouble(Double::doubleValue).toArray();
        res.rateTable          = rateTable;
        return res;
    }

    // ── Annuities ────────────────────────────────────────────────────────────

    public AnnuityResponse calculateAnnuity(AnnuityRequest req) {
        double PMT  = req.pmt;
        double i    = req.rate / 100.0;
        int    n    = req.n;
        String type = req.type;

        double v      = 1.0 / (1 + i);
        double pv     = 0, av = 0, unitA = 0, unitS = 0;
        String pvFormula = "", avFormula = "", info = "";
        double[] pmtSchedule = new double[0];

        switch (type) {
            case "immediate" -> {
                unitA     = (1 - Math.pow(v, n)) / i;
                unitS     = (Math.pow(1+i, n) - 1) / i;
                pv        = PMT * unitA;
                av        = PMT * unitS;
                pvFormula = "PMT × a_n|i = PMT × (1−vⁿ)/i";
                avFormula = "PMT × s_n|i = PMT × ((1+i)ⁿ−1)/i";
                info      = "Annuity-immediate: Payments made at the end of each period. First payment at t=1.";
            }
            case "due" -> {
                unitA     = (1 - Math.pow(v, n)) / (i * v);
                unitS     = (Math.pow(1+i, n) - 1) / (i * v);
                pv        = PMT * unitA;
                av        = PMT * unitS;
                pvFormula = "PMT × ä_n|i = PMT × (1−vⁿ)/d";
                avFormula = "PMT × s̈_n|i = PMT × ((1+i)ⁿ−1)/d";
                info      = "Annuity-due: Payments at the beginning of each period. PV is (1+i) times larger than annuity-immediate.";
            }
            case "deferred" -> {
                int    m   = 5;
                double a_n = (1 - Math.pow(v, n)) / i;
                unitA      = Math.pow(v, m) * a_n;
                unitS      = Math.pow(1+i, n) * unitA;
                pv         = PMT * unitA;
                av         = PMT * unitS;
                pvFormula  = "PMT × vᵐ × a_n|i  (m=5 deferral)";
                avFormula  = "PMT × (1+i)ⁿ × PV";
                info       = "Deferred annuity (m=5): Payments begin at time m=5, discounted an additional 5 periods.";
            }
            case "perpetuity" -> {
                unitA     = 1.0 / i;
                unitS     = Double.POSITIVE_INFINITY;
                pv        = PMT * unitA;
                av        = Double.POSITIVE_INFINITY;
                pvFormula = "PMT / i";
                avFormula = "∞ (no end)";
                info      = "Perpetuity-immediate: Payments continue forever. PV converges to PMT/i.";
            }
            case "perp-due" -> {
                double d  = i / (1 + i);
                unitA     = 1.0 / d;
                unitS     = Double.POSITIVE_INFINITY;
                pv        = PMT * unitA;
                av        = Double.POSITIVE_INFINITY;
                pvFormula = "PMT / d";
                avFormula = "∞ (no end)";
                info      = "Perpetuity-due: Payments start immediately. PV = PMT/d = PMT(1+i)/i.";
            }
            case "continuous" -> {
                double delta = Math.log(1 + i);
                unitA        = (1 - Math.pow(v, n)) / delta;
                unitS        = (Math.pow(1+i, n) - 1) / delta;
                pv           = PMT * unitA;
                av           = PMT * unitS;
                pvFormula    = "PMT × ā_n|δ = (1−e^(−δn))/δ";
                avFormula    = "PMT × s̄_n|δ = (e^(δn)−1)/δ";
                info         = "Continuous annuity: Uses force of interest δ instead of i.";
            }
            case "increasing", "decreasing" -> {
                int    dir      = type.equals("increasing") ? 1 : -1;
                String varyMode = req.varyMode != null ? req.varyMode : "arithmetic";
                double q        = req.q;
                int    ks       = req.ks, ke = Math.max(req.ke, ks);
                double g        = req.g / 100.0;
                int    gs       = req.gs, ge = Math.max(req.ge, gs);

                pmtSchedule = new double[n];
                for (int k = 1; k <= n; k++) {
                    double pmt = PMT;
                    if (varyMode.equals("arithmetic")) {
                        if (k >= ks && k <= ke) pmt = PMT + dir * q * (k - ks);
                        else if (k > ke)         pmt = PMT + dir * q * (ke - ks);
                        pmt = Math.max(0, pmt);
                    } else {
                        if (k >= gs && k <= ge) pmt = PMT * Math.pow(1 + dir * g, k - gs);
                        else if (k > ge)        pmt = PMT * Math.pow(1 + dir * g, ge - gs);
                        pmt = Math.max(0, pmt);
                    }
                    pmtSchedule[k - 1] = pmt;
                }

                double totalPmt = 0;
                for (double p : pmtSchedule) { totalPmt += p; }
                for (int k = 0; k < n; k++) {
                    pv += pmtSchedule[k] * Math.pow(v, k + 1);
                    av += pmtSchedule[k] * Math.pow(1+i, n - k - 1);
                }
                unitA     = pv / PMT;
                unitS     = av / PMT;
                String lbl      = type.equals("increasing") ? "Increasing" : "Decreasing";
                String modeLbl  = varyMode.equals("arithmetic")
                    ? "by $" + (long) q + " per period"
                    : "by " + String.format("%.1f", g * 100) + "% per period";
                pvFormula = "Σ PMTₖ × vᵏ  (" + lbl + ", " + modeLbl + ")";
                avFormula = "Σ PMTₖ × (1+i)^(n−k)";
                info      = lbl + " annuity (" + varyMode + "): Base PMT = $" +
                            String.format("%.0f", PMT) + ". Total cash paid: $" +
                            String.format("%.0f", totalPmt) + ".";
            }
        }

        // Build chart data
        boolean isPerp = type.equals("perpetuity") || type.equals("perp-due");
        boolean isVary = type.equals("increasing") || type.equals("decreasing");
        int periods    = isPerp ? Math.min(n, 30) : n;

        List<String> chartLabels = new ArrayList<>();
        List<Double> cumPV       = new ArrayList<>();
        List<Double> cumAV       = new ArrayList<>();
        List<Double> pmtBars     = new ArrayList<>();
        double cpv = 0, cav = 0;

        for (int k = 1; k <= periods; k++) {
            chartLabels.add("P" + k);
            if (isVary) {
                double p = pmtSchedule[k - 1];
                cpv += p * Math.pow(v, k);
                cav += p * Math.pow(1+i, periods - k);
                pmtBars.add(p);
            } else if (type.equals("immediate")) {
                cpv += PMT * Math.pow(v, k);       cav += PMT * Math.pow(1+i, periods - k + 1);
            } else if (type.equals("due")) {
                cpv += PMT * Math.pow(v, k - 1);   cav += PMT * Math.pow(1+i, periods - k + 1);
            } else if (type.equals("deferred")) {
                cpv += PMT * Math.pow(v, k + 5);   cav += PMT * Math.pow(1+i, periods - k + 1) * Math.pow(v, 5);
            } else if (isPerp) {
                cpv += PMT * Math.pow(v, k);       cav  = cpv * Math.pow(1+i, k);
            } else {
                cpv += PMT * Math.pow(v, k);       cav += PMT * Math.pow(1+i, periods - k + 1);
            }
            cumPV.add(cpv);
            cumAV.add(Double.isFinite(cav) ? cav : null);
        }

        AnnuityResponse res = new AnnuityResponse();
        res.pv        = pv;
        res.av        = av;
        res.unitA     = unitA;
        res.unitS     = unitS;
        res.pvFormula = pvFormula;
        res.avFormula = avFormula;
        res.info      = info;
        res.labels    = chartLabels.toArray(new String[0]);
        res.cumPV     = cumPV.stream().mapToDouble(Double::doubleValue).toArray();
        res.cumAV     = cumAV.stream().mapToDouble(d2 -> d2 != null ? d2 : Double.NaN).toArray();
        res.pmtBars   = pmtBars.stream().mapToDouble(Double::doubleValue).toArray();
        return res;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private String fmt(double val, int decimals) {
        return String.format("%." + decimals + "f", val);
    }
}
